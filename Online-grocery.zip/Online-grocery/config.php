<?php

$conn = mysqli_connect('localhost','root','','db2') or die('connection failed');

?>