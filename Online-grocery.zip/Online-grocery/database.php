<?php 
$con=mysqli_connect('localhost','root','','onlinegrocery');
if(mysqli_connect_errno($con)){
     echo 'Error!';
}
?>
