<?php 
$link = mysqli_connect('localhost', 'root', '', 'onlinegrocery');

// Check connection
if (!$link) {
    die('Error: Unable to connect - ' . mysqli_connect_error());
} else {
//     echo 'Connected successfully!';
}
?>
